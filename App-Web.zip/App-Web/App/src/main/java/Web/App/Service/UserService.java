package Web.App.Service;

import Web.App.Model.DTO.User;

public interface UserService {
        User authenticate(String email, String password);
}
