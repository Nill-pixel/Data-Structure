package Web.App.Service;

import Web.App.Model.DTO.Product;

public interface ProductService {
    Product getProductById(int id);
}
