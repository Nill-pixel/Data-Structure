package Web.App.Model.DTO;

import jakarta.persistence.*;

@Entity
@Table(name = "loja")
public class Shop {
    @ManyToOne
    @JoinColumn(name = "ID_Endereco")
    private Address address;
    @Column(name = "Numero")
    private int number;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "Nome")
    private String name;
    @Column(name = "Password")
    private String password;
    @Column(name = "Descricao")
    private String description;

    @Column(name = "Email")
    private String email;
    @Column(length = 64)
    private String photos;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhotos() {
        return photos;
    }

    public void setPhotos(String photos) {
        this.photos = photos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
