package Web.App.Service;

import Web.App.Model.DTO.Shop;

public interface ShopService {
    Shop getShopByID(int id);

    Shop authenticate(String email, String password);
}
