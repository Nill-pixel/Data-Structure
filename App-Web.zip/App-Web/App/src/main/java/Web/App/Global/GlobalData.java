package Web.App.Global;

import Web.App.Model.DTO.Product;
import Web.App.Model.DTO.Shop;
import Web.App.Model.DTO.User;

import java.util.ArrayList;
import java.util.List;

public class GlobalData {
    public static List<Product> cart;
    public static List<User> users;
    public static List<Shop> shops;
    static {
        cart = new ArrayList<>();
    }
    static {
        users = new ArrayList<>();
    }
    static {
        shops = new ArrayList<>();
    }
}
